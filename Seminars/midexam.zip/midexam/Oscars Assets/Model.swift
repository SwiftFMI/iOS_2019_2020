import UIKit

struct Movie {
    let title: String
    let posterImage: UIImage?
    let storyline: String
}

struct Nomination {
    let movie: Movie
    let sentiment: UIImage?
    let personName: String?
    let personPicture: UIImage?
}

struct Category {
    let name: String
    let nominees: [Nomination]
}

struct Model {
    let predictions = [
        Category(
            name: "BEST PICTURE:",
            nominees: bestPictrure
        ),
        Category(
            name: "BEST DIRECTOR",
            nominees: bestDirector
        ),
        Category(
            name: "BEST ACTOR:",
            nominees: bestActor
        ),
        Category(
            name: "BEST ACTRESS:",
            nominees: bestActress
        )
    ]
    
    private static let bestPictrure = [
        Nomination(
            movie: Movie(
                title: "ONCE UPON A TIME…IN HOLLYWOOD",
                posterImage: UIImage(named: "once_upon_a_time_in_hollywood"),
                storyline: "Quentin Tarantino's Once Upon a Time... in Hollywood visits 1969 Los Angeles, where everything is changing, as TV star Rick Dalton (Leonardo DiCaprio) and his longtime stunt double Cliff Booth (Brad Pitt) make their way around an industry they hardly recognize anymore. The ninth film from the writer-director features a large ensemble cast and multiple storylines in a tribute to the final moments of Hollywood's golden age."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "THE IRISHMAN",
                posterImage: UIImage(named: "the_irishman"),
                storyline: "Frank \"The Irishman\" Sheeran is a man with a lot on his mind. The former labor union high official and hitman, learned to kill serving in Italy during the Second World War. He now looks back on his life and the hits that defined his mob career, maintaining connections with the Bufalino crime family. In particular, the part he claims to have played in the disappearance of his life-long friend, Jimmy Hoffa, the former president of the International Brotherhood of Teamsters, who mysteriously vanished in late July 1975 at the age of 62."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "MARRIAGE STORY",
                posterImage: UIImage(named: "marriage_story"),
                storyline: "MARRIAGE STORY is Academy Award nominated filmmaker Noah Baumbach's incisive and compassionate look at a marriage breaking up and a family staying together. The film stars Scarlett Johansson and Adam Driver. Laura Dern, Alan Alda, and Ray Liotta co-star."
            ),
            sentiment: UIImage(named: "up"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "JOJO RABBIT",
                posterImage: UIImage(named: "jojo_rabbit"),
                storyline: "A World War II satire that follows a lonely German boy named Jojo (Roman Griffin Davis) whose world view is turned upside down when he discovers his single mother (Scarlett Johansson) is hiding a young Jewish girl (Thomasin McKenzie) in their attic. Aided only by his idiotic imaginary friend, Adolf Hitler (Taika Waititi), Jojo must confront his blind nationalism."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "PARASITE",
                posterImage: UIImage(named: "parasite"),
                storyline: "Jobless, penniless, and, above all, hopeless, the unmotivated patriarch, Ki-taek, and his equally unambitious family--his supportive wife, Chung-sook; his cynical twentysomething daughter, Ki-jung, and his college-age son, Ki-woo--occupy themselves by working for peanuts in their squalid basement-level apartment. Then, by sheer luck, a lucrative business proposition will pave the way for an insidiously subtle scheme, as Ki-woo summons up the courage to pose as an English tutor for the teenage daughter of the affluent Park family. Now, the stage seems set for an unceasing winner-take-all class war. How does one get rid of a parasite?"
            ),
            sentiment: UIImage(named: "neutral"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "1917",
                posterImage: UIImage(named: "1917"),
                storyline: "Schofield and Blake, two young British soldiers during the First World War, are given a seemingly impossible mission. With time against them, they must deliver a message, deep in enemy territory, that will stop their own men, and Blake's own brother, walking straight into a deadly trap."
            ),
            sentiment: UIImage(named: "up"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "JOKER",
                posterImage: UIImage(named: "joker"),
                storyline: "Joker centers around an origin of the iconic arch nemesis and is an original, standalone story not seen before on the big screen. Todd Phillips' exploration of Arthur Fleck (Joaquin Phoenix), a man disregarded by society is not only a gritty character study, but also a broader cautionary tale."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: nil,
            personPicture: nil
        ),
        Nomination(
            movie: Movie(
                title: "THE FAREWELL",
                posterImage: UIImage(named: "the_farewell"),
                storyline: "A headstrong Chinese-American woman returns to China when her beloved grandmother is diagnosed with terminal cancer. Billi struggles with her family's decision to keep grandma in the dark about her own illness as they all stage an impromptu wedding to see grandma one last time."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: nil,
            personPicture: nil
        )
    ]

    private static let bestDirector = [
        Nomination(
            movie: Movie(
                title: "ONCE UPON A TIME…IN HOLLYWOOD",
                posterImage: UIImage(named: "once_upon_a_time_in_hollywood"),
                storyline: "Quentin Tarantino's Once Upon a Time... in Hollywood visits 1969 Los Angeles, where everything is changing, as TV star Rick Dalton (Leonardo DiCaprio) and his longtime stunt double Cliff Booth (Brad Pitt) make their way around an industry they hardly recognize anymore. The ninth film from the writer-director features a large ensemble cast and multiple storylines in a tribute to the final moments of Hollywood's golden age."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Quentin Tarantino",
            personPicture: UIImage(named: "quentin_tarantino")
        ),
        Nomination(
            movie: Movie(
                title: "THE IRISHMAN",
                posterImage: UIImage(named: "the_irishman"),
                storyline: "Frank \"The Irishman\" Sheeran is a man with a lot on his mind. The former labor union high official and hitman, learned to kill serving in Italy during the Second World War. He now looks back on his life and the hits that defined his mob career, maintaining connections with the Bufalino crime family. In particular, the part he claims to have played in the disappearance of his life-long friend, Jimmy Hoffa, the former president of the International Brotherhood of Teamsters, who mysteriously vanished in late July 1975 at the age of 62."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Martin Scorsese",
            personPicture: UIImage(named: "martin_scorsese")
        ),
        Nomination(
            movie: Movie(
                title: "PARASITE",
                posterImage: UIImage(named: "parasite"),
                storyline: "Jobless, penniless, and, above all, hopeless, the unmotivated patriarch, Ki-taek, and his equally unambitious family--his supportive wife, Chung-sook; his cynical twentysomething daughter, Ki-jung, and his college-age son, Ki-woo--occupy themselves by working for peanuts in their squalid basement-level apartment. Then, by sheer luck, a lucrative business proposition will pave the way for an insidiously subtle scheme, as Ki-woo summons up the courage to pose as an English tutor for the teenage daughter of the affluent Park family. Now, the stage seems set for an unceasing winner-take-all class war. How does one get rid of a parasite?"
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Bong Joon-ho",
            personPicture: UIImage(named: "bong_joon-ho")
        ),
        Nomination(
            movie: Movie(
                title: "1917",
                posterImage: UIImage(named: "1917"),
                storyline: "Schofield and Blake, two young British soldiers during the First World War, are given a seemingly impossible mission. With time against them, they must deliver a message, deep in enemy territory, that will stop their own men, and Blake's own brother, walking straight into a deadly trap."
            ),
            sentiment: UIImage(named: "up"),
            personName: "Sam Mendes",
            personPicture: UIImage(named: "sam_mendes")
        ),
        Nomination(
            movie: Movie(
                title: "MARRIAGE STORY",
                posterImage: UIImage(named: "marriage_story"),
                storyline: "MARRIAGE STORY is Academy Award nominated filmmaker Noah Baumbach's incisive and compassionate look at a marriage breaking up and a family staying together. The film stars Scarlett Johansson and Adam Driver. Laura Dern, Alan Alda, and Ray Liotta co-star."
            ),
            sentiment: UIImage(named: "down"),
            personName: "Noah Baumbach",
            personPicture: UIImage(named: "noah_baumbach")
        )
    ]

    private static let bestActor = [
        Nomination(
            movie: Movie(
                title: "JOKER",
                posterImage: UIImage(named: "joker"),
                storyline: "Joker centers around an origin of the iconic arch nemesis and is an original, standalone story not seen before on the big screen. Todd Phillips' exploration of Arthur Fleck (Joaquin Phoenix), a man disregarded by society is not only a gritty character study, but also a broader cautionary tale."
            ),
            sentiment: UIImage(named: "up"),
            personName: "Joaquin Phoenix",
            personPicture: UIImage(named: "joaquin_phoenix")
        ),
        Nomination(
            movie: Movie(
                title: "MARRIAGE STORY",
                posterImage: UIImage(named: "marriage_story"),
                storyline: "MARRIAGE STORY is Academy Award nominated filmmaker Noah Baumbach's incisive and compassionate look at a marriage breaking up and a family staying together. The film stars Scarlett Johansson and Adam Driver. Laura Dern, Alan Alda, and Ray Liotta co-star."
            ),
            sentiment: UIImage(named: "down"),
            personName: "Adam Driver",
            personPicture: UIImage(named: "adam_driver")
        ),
        Nomination(
            movie: Movie(
                title: "PAIN AND GLORY",
                posterImage: UIImage(named: "pain_and_glory"),
                storyline: "The protagonist of \"Pain and Glory\" was at the decline of his career. The man involuntarily looks back into the past, and a stream of vivid memories falls upon him. He recalls such moments from his youth as tender feelings for his mother, love and separation, the search for happiness and success. All this leads the master of cinema to important thoughts about life and art, because this is the most important thing for him."
            ),
            sentiment: UIImage(named: "up"),
            personName: "Antonio Banderas",
            personPicture: UIImage(named: "antonio_banderas")
        ),
        Nomination(
            movie: Movie(
                title: "THE IRISHMAN",
                posterImage: UIImage(named: "the_irishman"),
                storyline: "Frank \"The Irishman\" Sheeran is a man with a lot on his mind. The former labor union high official and hitman, learned to kill serving in Italy during the Second World War. He now looks back on his life and the hits that defined his mob career, maintaining connections with the Bufalino crime family. In particular, the part he claims to have played in the disappearance of his life-long friend, Jimmy Hoffa, the former president of the International Brotherhood of Teamsters, who mysteriously vanished in late July 1975 at the age of 62."
            ),
            sentiment: UIImage(named: "down"),
            personName: "Robert De Niro",
            personPicture: UIImage(named: "robert_de_niro")
        ),
        Nomination(
            movie: Movie(
                title: "ONCE UPON A TIME…IN HOLLYWOOD",
                posterImage: UIImage(named: "once_upon_a_time_in_hollywood"),
                storyline: "Quentin Tarantino's Once Upon a Time... in Hollywood visits 1969 Los Angeles, where everything is changing, as TV star Rick Dalton (Leonardo DiCaprio) and his longtime stunt double Cliff Booth (Brad Pitt) make their way around an industry they hardly recognize anymore. The ninth film from the writer-director features a large ensemble cast and multiple storylines in a tribute to the final moments of Hollywood's golden age."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Leonardo DiCaprio",
            personPicture: UIImage(named: "leonardo_di_caprio")
        )
    ]

    private static let bestActress = [
        Nomination(
            movie: Movie(
                title: "JUDY",
                posterImage: UIImage(named: "judy"),
                storyline: "Legendary performer Judy Garland arrives in London in the winter of 1968 to perform a series of sold-out concerts."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Renée Zellweger",
            personPicture: UIImage(named: "renee_zellweger")
        ),
        Nomination(
            movie: Movie(
                title: "MARRIAGE STORY",
                posterImage: UIImage(named: "marriage_story"),
                storyline: "MARRIAGE STORY is Academy Award nominated filmmaker Noah Baumbach's incisive and compassionate look at a marriage breaking up and a family staying together. The film stars Scarlett Johansson and Adam Driver. Laura Dern, Alan Alda, and Ray Liotta co-star."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Scarlett Johansson",
            personPicture: UIImage(named: "scarlett_johansson")
        ),
        Nomination(
            movie: Movie(
                title: "LITTLE WOMEN",
                posterImage: UIImage(named: "little_wommen"),
                storyline: "Four sisters come of age in America in the aftermath of the Civil War."
            ),
            sentiment: UIImage(named: "neutral"),
            personName: "Saorise Ronan",
            personPicture: UIImage(named: "saorise_ronan ")
        ),
        Nomination(
            movie: Movie(
                title: "CLEMENCY",
                posterImage: UIImage(named: "clemency"),
                storyline: "Years of carrying out death row executions have taken a toll on prison warden Bernadine Williams. As she prepares to execute another inmate, Bernadine must confront the psychological and emotional demons her job creates, ultimately connecting her to the man she is sanctioned to kill."
            ),
            sentiment: UIImage(named: "up"),
            personName: "Alfre Woodard",
            personPicture: UIImage(named: "alfre_woodard")
        ),
        Nomination(
            movie: Movie(
                title: "US",
                posterImage: UIImage(named: "once_upon_a_time_in_hollywood"),
                storyline: "In order to get away from their busy lives, the Wilson family takes a vacation to Santa Cruz, California with the plan of spending time with their friends, the Tyler family. On a day at the beach, their young son Jason almost wanders off, causing his mother Adelaide to become protective of her family. That night, four mysterious people break into Adelaide's childhood home where they're staying. The family is shocked to find out that the intruders look like them, only with grotesque appearances."
            ),
            sentiment: UIImage(named: "down"),
            personName: "Lupita Nyong’o",
            personPicture: UIImage(named: "lupita_nyongo")
        )
    ]
}
